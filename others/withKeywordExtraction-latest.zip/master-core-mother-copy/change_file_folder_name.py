import os
# # cannot handle file names with spaces hence remove with _
from paramConfig  import config
import re as r
import string

# os.chdir(config.inputPath)
# for file_nm in os.listdir(config.inputPath):
    # cmd ='ren  "'+os.path.join('', file_nm)+'" '+ os.path.join('', file_nm.replace(' ', '_'))
    # os.system(cmd)
# os.chdir(config.filePath+"code/")

# cmd = "iPython ./file_to_csv.py"
# os.system(cmd)

# # cannot handle file names with spaces hence remove with _
# from paramConfig  import config
#os.chdir(config.inputPath)

# for file_nm in os.listdir(config.inputPath):
    # cmd ='ren  "'+os.path.join('', file_nm)+'" '+ os.path.join('', file_nm.replace(' ', '_'))
    # os.system(cmd)
# os.chdir(config.filePath+"code/")

filePath = config.filePath
rfpinputPath = config.rfpinPath
inputPath = config.inputPath
outputPath = config.outfilePath


alldirs = []
allfiles = []
for root, dirs, files in os.walk(rfpinputPath):
    for dir in dirs:
        alldirs.append(os.path.join(root, dir))
    for filenm in files:
        allfiles.append(os.path.join(root, filenm))

for filenm in allfiles:
    if filenm.find(' ') != -1:
        print(filenm)
        print(filenm.replace(' ','-'))
        new_file_name = ''.join(c for c in filenm if c in string.printable)
        os.rename(os.path.join(filenm), os.path.join( new_file_name).replace(' ','-'))  
        #os.rename(os.path.join(filenm),os.path.join('xxx'.replace(' ','-')))
        
alldirs.sort()
alldirs.reverse()

for dir in alldirs:
    if dir.find(' ') != -1:
        print(dir)
        os.chdir(dir)
        print(dir.replace(' ','-'))
        os.rename(os.path.join(dir),os.path.join(dir.replace(' ','-')))