# -*- coding: utf-8 -*-
"""
Created on Fri May 20 15:11:49 2016

@author: 108216
"""

from sklearn.datasets import fetch_20newsgroups

categories = [
    'alt.atheism',
    'talk.religion.misc',
    # 'comp.graphics'
]
# Uncomment the following to do the analysis on all the categories
#categories = None

print("Loading 20 newsgroups dataset for categories:")
print(categories)

dataset = fetch_20newsgroups(subset='all', categories=categories,
                             shuffle=True, random_state=42)
dataset.target

import pandas as pd
data =  pd.DataFrame()
data['fileId'] = dataset.filenames
data['score'] = dataset.target
data['content'] = dataset.data
from paramConfig  import config

filePath = config.filePath
inputPath = config.inputPath

import sys
sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
data.to_csv(filePath+"/data/file_corpora.tsv",sep='\t',index =False)
