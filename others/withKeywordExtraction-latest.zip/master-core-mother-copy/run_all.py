import os
cmd = "iPython ./change_file_folder_name.py"
os.system(cmd)

cmd = "iPython ./file_list.py"
os.system(cmd)

cmd = "iPython ./files_to_csv_v2.py"
os.system(cmd)

# cmd = "iPython ./feature_stem.py"
# os.system(cmd)

# cmd = "iPython ./word2vec.py"
# os.system(cmd)

# cmd = "iPython ./feature_stem_gramupto5.py"
# os.system(cmd)

# cmd = "R CMD BATCH ./check_model_xgb.R"
# os.system(cmd)