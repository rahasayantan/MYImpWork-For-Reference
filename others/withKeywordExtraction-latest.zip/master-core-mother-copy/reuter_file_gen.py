# -*- coding: utf-8 -*-
"""
Created on Fri May 20 22:50:51 2016

@author: Raha
"""

from sklearn.datasets import fetch_20newsgroups
categories = [
    'alt.atheism',
    'talk.religion.misc',
    'comp.graphics',
    'sci.space',
]
# Uncomment the following to do the analysis on all the categories
#categories = None

print("Loading 20 newsgroups dataset for categories:")
print(categories)

dataset = fetch_20newsgroups(subset='all', categories=categories,
                             shuffle=True, random_state=42)

print("%d documents" % len(dataset.data))
print("%d categories" % len(dataset.target_names))



import pandas as pd
frame = pd.DataFrame()
frame['fileId'] = dataset.filenames
frame['score'] = dataset.target
frame['content'] = dataset.data

from paramConfig  import config

filePath = config.filePath
inputPath = config.inputPath

import sys

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')


frame.to_csv(filePath+"/data/file_corpora.tsv",sep='\t',index =False)
