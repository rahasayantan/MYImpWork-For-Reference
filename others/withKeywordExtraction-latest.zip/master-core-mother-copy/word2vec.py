import nltk
import pandas as pd
from paramConfig import config
from gensim.models import Word2Vec
import re
import numpy as np
stopwords = config.stopwords

def preProcess_data(line,exclude_stopword=False):
    token_pattern = re.compile(config.token_pattern, flags = re.UNICODE | re.LOCALE)
    ##tokenize
    tokens = [x.lower() for x in token_pattern.findall(line)]
    tokens_stemmed = tokens
    if exclude_stopword:
        tokens_stemmed = [x for x in tokens_stemmed if x not in config.stopwords]
    return tokens_stemmed

def text_to_sentences( text, tokenizer, remove_stopwords=False ):
    raw_sentences = tokenizer.tokenize(text.decode('utf8').strip())
    sentences = []
    for raw_sentence in raw_sentences:
        if len(raw_sentence) > 0:
            sentences.append( raw_sentence.lower().split())
    return sentences
def makeFeatureVec(words, model, num_features):
    # Function to average all of the word vectors in a given
    # paragraph
    #
    # Pre-initialize an empty numpy array (for speed)
    featureVec = np.zeros((num_features,),dtype="float32")
    #
    nwords = 0.
    #
    # Index2word is a list that contains the names of the words in
    # the model's vocabulary. Convert it to a set, for speed
    index2word_set = set(model.index2word)
    #
    # Loop over each word in the review and, if it is in the model's
    # vocaublary, add its feature vector to the total
    for word in words:
        if word in index2word_set:
            nwords = nwords + 1.
            featureVec = np.add(featureVec,model[word])
    #
    # Divide the result by the number of words to get the average
    featureVec = np.divide(featureVec,nwords)
    return featureVec


def getAvgFeatureVecs(text, model, num_features):
    # Given a set of text (each one a list of words), calculate
    # the average feature vector for each one and return a 2D numpy array
    #
    # Initialize a counter
    counter = 0.
    #
    # Preallocate a 2D numpy array, for speed
    reviewFeatureVecs = np.zeros((len(text),num_features),dtype="float32")
    #
    # Loop through the text
    for review in text:
       #
       # Print a status message every 1000th review
       if counter%1000. == 0.:
           print "Review %d of %d" % (counter, len(text))
       #
       # Call the function (defined above) that makes average feature vectors
       reviewFeatureVecs[counter] = makeFeatureVec(review, model, \
           num_features)
       #
       # Increment the counter
       counter = counter + 1.
    return reviewFeatureVecs


def getCleanText(text):
    clean_text = []
    for review in text:
        clean_text.append( preProcess_data( review, exclude_stopword=True ))
    return clean_text


if __name__ == '__main__':
    sent_tokenizer=nltk.data.load('tokenizers/punkt/english.pickle')
    train = pd.read_csv(config.inputPath+"file_corpora.tsv" ,sep="\t")
    sentences = []
    for text in train["content"]:
        sentences += text_to_sentences(text, sent_tokenizer)
    sentences
    # Set values for various parameters
    num_features = 300    # Word vector dimensionality
    min_word_count = 5   # Minimum word count
    num_workers = 4       # Number of threads to run in parallel
    context = 10          # Context window size
    downsampling = 1e-5   # Downsample setting for frequent words
    alpha = .001
    iter = 15
	

    # Initialize and train the model (this will take some time)
    print "Training Word2Vec model..."
    model = Word2Vec(sentences, workers=num_workers, \
                size=num_features, min_count = min_word_count, \
                window = context, sample = downsampling, seed=1,alpha=alpha,iter=iter)
    #model = Word2Vec.load_word2vec_format(config.inputPath+'GoogleNews-vectors-negative300.bin', binary=True)			
    model.init_sims(replace=True)
    model_name = "300features_5minwords_10context"
    model.save(model_name)

    model.doesnt_match("man woman child kitchen".split())
    train_fold = pd.read_csv(config.inputPath+"fold.tsv" ,sep="\t")
    trainId = train_fold[train_fold['train_fold0'] ==1.0].index.tolist()
    valId = train_fold[train_fold['train_fold0'] ==0.0].index.tolist()
    X_train = train.loc[trainId,].reset_index(drop=True)
    X_valid = train.loc[valId,].reset_index(drop=True)
    trainDataVecs = getAvgFeatureVecs( getCleanText(X_train["content"]), model, num_features )
    testDataVecs = getAvgFeatureVecs( getCleanText(X_valid["content"]), model, num_features )
    col_nm = []
    x = pd.DataFrame(trainDataVecs)
    for col in x.columns:
        col = 'w2vec'+str(col)
        col_nm.append(col)
    x.columns = col_nm

    frames = [X_train,x]
    X_train=pd.concat(frames,axis=1)
    X_train.drop('content', axis=1, inplace=True)
    X_train.to_csv(config.inputPath+"xtrain_word2vec_300.tsv",sep='\t')
    x = pd.DataFrame(testDataVecs)
    col_nm = []
    for col in x.columns:
        col = 'w2vec'+str(col)
        col_nm.append(col)
    x.columns = col_nm

    frames = [X_valid,x]
    X_valid=pd.concat(frames,axis=1)
    X_valid.drop('content', axis=1, inplace=True)
    X_valid.to_csv(config.inputPath+"xtest_word2vec_300.tsv",sep='\t',index=False,header=True)