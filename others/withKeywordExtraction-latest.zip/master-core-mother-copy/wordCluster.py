import pandas as pd
from paramConfig import config
from gensim.models import Word2Vec
import re
import numpy as np

model = Word2Vec.load("100features_5minwords_10context")

from sklearn.cluster import KMeans
word_vectors = model.syn0
num_clusters = word_vectors.shape[0] / 5
kmeans_clustering = KMeans( n_clusters = num_clusters )
idx = kmeans_clustering.fit_predict( word_vectors )