##Document Dump
from nltk.corpus import PlaintextCorpusReader
import numpy as np
import pandas as pd
from paramConfig  import config
import sys
import  re

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
r = re.compile(r"\s")

corpusRoot = config.outfilePath
inputPath = config.inputPath
fileList = PlaintextCorpusReader(corpusRoot, '.*.txt')
fileList.fileids()


data =  pd.DataFrame()
data['fileId'] = fileList.fileids()
data['score'] = np.arange(0,len(data['fileId']))

########Should be commented later on

# data.loc[0:55,'score']=1
# data.loc[56:80,'score']=2
# data.loc[81:85,'score']=3
# data.loc[86:95,'score']=4
# data.loc[96:,'score']=2
# ############################
# data['content'] = str('Empty')


for fileid in fileList.fileids():
    with open(corpusRoot+fileid, 'r') as myfile:
        txt=unicode(myfile.read().replace('\n', ' ').replace('\t',' ').strip(),errors="replace")
        txt = r.sub(' ',txt)
        data.loc[data['fileId']==fileid,'content']=txt
        
data
data.to_csv(inputPath+"file_corpora.tsv",sep='\t',index =False)
text=''
for i in np.arange(len(data)):
    text='.'.join([text,data.loc[i,'content']])

## key word extraction  using Rake -- best so far
import rake
import operator
rake_object = rake.Rake("SmartStoplist.txt", 4, 5, 20)#Each word has at least 4 characters, Each phrase has at most 5 words, Each keyword appears in the text at least 20 times
#sample_file = open("data/docs/fao_test/w2167e.txt", 'r')
#text = sample_file.read()
#text = data['content'][0]
keywords = rake_object.run(text)
print "Keywords:", keywords

stoppath = "SmartStoplist.txt"

rake_object = rake.Rake(stoppath)

text = "Compatibility of systems of linear constraints over the set of natural numbers. Criteria of compatibility " \
       "of a system of linear Diophantine equations, strict inequations, and nonstrict inequations are considered. " \
       "Upper bounds for components of a minimal set of solutions and algorithms of construction of minimal generating"\
       " sets of solutions for all types of systems are given. These criteria and the corresponding algorithms " \
       "for constructing a minimal supporting set of solutions can be used in solving all the considered types of " \
       "systems and systems of mixed types."
sentenceList = rake.split_sentences(text)
stopwordpattern = rake.build_stop_word_regex(stoppath)
phraseList = rake.generate_candidate_keywords(sentenceList, stopwordpattern)
wordscores = rake.calculate_word_scores(phraseList)
keywordcandidates = rake.generate_candidate_keyword_scores(phraseList, wordscores)
sortedKeywords = sorted(keywordcandidates.iteritems(), key=operator.itemgetter(1), reverse=True)
totalKeywords = len(sortedKeywords)

for keyword in sortedKeywords[0:(totalKeywords / 3)]:
    print "Keyword: ", keyword[0], ", score: ", keyword[1]       

## key word extraction  using Gensim -- not good either
import logging
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
from gensim.summarization import summarize

text=text.decode('utf-8','ignore').encode("utf-8").strip()

print 'Summary:'
print summarize(text)

print summarize(text, split=True)

print 'Summary:'
print summarize(text, ratio=0.5)
print 'Summary:'
print summarize(text, word_count=500)

from gensim.summarization import keywords

print 'Keywords:'
print keywords(text)


#remove stopwords and check - very bad
import nltk
from nltk.collocations import *
bigram_measures = nltk.collocations.BigramAssocMeasures()

# change this to read in your data
finder = BigramCollocationFinder.from_words(
   text.split())

# only bigrams that appear 3+ times
finder.apply_freq_filter(3) 

# return the 5 n-grams with the highest PMI
finder.nbest(bigram_measures.pmi, 5)  #check what is PMI in NLTK


