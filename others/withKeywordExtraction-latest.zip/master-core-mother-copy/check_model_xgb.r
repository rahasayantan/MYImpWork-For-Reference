library(readr)
library(data.table)

library(Matrix)
# train <- fread("D:/data-kaggle/textClassTemplate/data/xtrain_bow_stem_svd100_gram5.tsv")
# test <- fread("D:/data-kaggle/textClassTemplate/data/xtest_bow_stem_svd100_gram5.tsv")

train.1 <- fread("D:/data-kaggle/textClassTemplate/data/xtrain_tfidf_stem_svd100_gram5.tsv")#best
test.1 <- fread("D:/data-kaggle/textClassTemplate/data/xtest_tfidf_stem_svd100_gram5.tsv")
train.2 <- fread("D:/data-kaggle/textClassTemplate/data/xtrain_word2vec_300.tsv")
test.2 <- fread("D:/data-kaggle/textClassTemplate/data/xtest_word2vec_300.tsv")
train.1[,":="(V1=NULL,fileId=NULL)]
train.2[,":="(V1=NULL,fileId=NULL)]


y <- train.1[,score]
#y <- y-1

test.1[,":="(V1=NULL,fileId=NULL)]
test.2[,":="(V1=NULL,fileId=NULL)]
y_test <- test.1[,score]
#y_test <- y_test-1
test.1[,score:=NULL]
train.1[,score:=NULL]
test.2[,score:=NULL]
train.2[,score:=NULL]

train <- cbind(train.1,train.2)
test <- cbind(test.1,test.2)
library(xgboost)
x0d <- xgb.DMatrix(sparse.model.matrix(y~.,data=train), label = y)
x1d <- xgb.DMatrix(sparse.model.matrix(y_test~.,data=test), label = y_test)

xgb.param <- list(                     
  eta = 0.01,
  max.depth = 6, 
  colsample_bytree = 1,
  subsample = 1,
  gamma = 0.01,
  min_child_weight = 1
)
set.seed(1234)
clf <- xgboost(booster = "gbtree",
              data = x0d,
                 params = xgb.param,
                 maximize = F, 
                 print.every.n = 1,
                 early.stop.round = 10,
                 nrounds = 1000,
                 objective = "multi:softmax",
                 num_class=2,
                 eval_metric = "mlogloss")##merror
target <- predict(clf,x1d)

x<-table(y_test,target)
write.csv(x,"D:/data-kaggle/textClassTemplate/data/R-op.csv")


imp <- xgb.importance(model=clf,feature_names = colnames(train))
write.csv(imp,"D:/data-kaggle/textClassTemplate/data/Ftr-Imp.csv")

# 
# library(MLmetrics)
# MultiLogLoss()

# bow
# target
# y_test   0   1   2   3
# 0 191   4  22  50
# 1   3 244  76   2
# 2   2   8 316   3
# 3  80   1  42  87
# 
# tfidf
# 
# target
# y_test   0   1   2   3
# 0 199   4  17  47
# 1   4 239  80   2
# 2   2  11 314   2
# 3  83   3  38  86
# 
# word2vec
# y_test   0   1   2   3
# 0 199  17  27  24
# 1  31 253  34   7
# 2  27  31 266   5
# 3  61  19  23 107

# w2vec svd combo
# target
# y_test   0   1   2   3
# 0 199   3  19  46
# 1   3 256  65   1
# 2   1   9 316   3
# 3  63   2  42 103