# -*- coding: utf-8 -*-
"""
Created on Mon May 16 11:25:42 2016

@author: 108216
"""

from sklearn.cross_validation import StratifiedKFold
import pandas as pd
from paramConfig  import config

inputPath = config.inputPath

## CV params
n_runs = 3
n_folds = 3


label = "score"
key = "fileId"
skf = [0]*n_runs
train = pd.read_csv(inputPath+"file_corpora.tsv" ,sep="\t")
train_fold = pd.DataFrame(train['fileId'])
rand_seed = 2016+1000
skf = StratifiedKFold(train['score'],n_folds = n_folds,shuffle  = True, random_state=rand_seed)
for fold, (trainInd,validInd) in enumerate(skf):
#    print("================================")
#    print("Train (num = %s)" % len(trainInd))
#    print(trainInd)
#    print("Valid (num = %s)" % len(validInd))
#    print(validInd)
    train_fold.loc[trainInd,'train_fold%s'%(fold)] = 1
    train_fold.loc[validInd,'train_fold%s'%(fold)] = 0
        
train_fold.to_csv("..\\data\\fold.tsv",sep='\t',index =False)
