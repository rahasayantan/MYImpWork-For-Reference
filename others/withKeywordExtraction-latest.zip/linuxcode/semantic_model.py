import collections
import itertools
import networkx as nx
from cytoolz import itertoolz
from nltk.corpus import PlaintextCorpusReader
import numpy as np
import pandas as pd
from paramConfig  import config
import sys
import  re

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
r = re.compile(r"\s")

corpusRoot = config.outfilePath
inputPath = config.inputPath
fileList = PlaintextCorpusReader(corpusRoot, '.*.txt')
fileList.fileids()


data =  pd.DataFrame()
data['fileId'] = fileList.fileids()
data['score'] = np.arange(0,len(data['fileId']))

for fileid in fileList.fileids():
    with open(corpusRoot+fileid, 'r') as myfile:
        txt=unicode(myfile.read().replace('\n', ' ').replace('\t',' ').strip(),errors="replace")
        txt = r.sub(' ',txt)
        data.loc[data['fileId']==fileid,'content']=txt
        
data
data.to_csv(inputPath+"file_corpora.csv",sep=',',index =False)

def terms_to_semantic_network(terms,
                              window_width=10,
                              edge_weighting='cooc_freq'):

    windows = itertoolz.sliding_window(window_width, terms)
    graph = nx.Graph()

    if edge_weighting == 'cooc_freq':
        cooc_mat = collections.defaultdict(lambda: collections.defaultdict(int))
        for window in windows:
            for w1, w2 in itertools.combinations(sorted(window), 2):
                cooc_mat[w1][w2] += 1
        graph.add_edges_from(
            (w1, w2, {'weight': cooc_mat[w1][w2]})
            for w1, w2s in cooc_mat.items() for w2 in w2s)

    elif edge_weighting == 'binary':
        graph.add_edges_from(
            w1_w2 for window in windows
            for w1_w2 in itertools.combinations(window, 2))

    return graph

#apply syntactic filters based on POS tags
def filter_for_tags(tagged, tags=['JJ','JJR','JJS','NN','NNP','NNS','NNPS']):
    return [item for item in tagged if item[1] in tags]
    
window_width=3
edge_weighting='cooc_freq'
join_key_words=True
n_keyterms=.01


sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
wordTokens = nltk.word_tokenize(' '.join(sent_detector.tokenize(text.strip())))
wordTokens = [x.lower() for x in wordTokens]
wordTokens = [x for x in wordTokens if x not in stopwords]
wordTokens = stem_tokens(wordTokens,english_stemmer)
tagged = nltk.pos_tag(wordTokens)
textlist = [x[0] for x in tagged]

tagged = filter_for_tags(tagged)
tagged = [x[0] for x in normalize(tagged)]
wordTokens = tagged

if isinstance(n_keyterms, float):
    if not 0.0 < n_keyterms <= 1.0:
        raise ValueError('`n_keyterms` must be an int, or a float between 0.0 and 1.0')
    n_keyterms = int(n_keyterms * len(set(wordTokens)))

graph = terms_to_semantic_network(
    wordTokens, window_width=window_width, edge_weighting=edge_weighting)

word_ranks = nx.pagerank_scipy(graph, weight='weight')
# elif ranking_algo == 'divrank':
    # word_ranks = rank_nodes_by_divrank(
        # graph, r=None, lambda_=kwargs.get('lambda_', 0.5), alpha=kwargs.get('alpha', 0.5))
# elif ranking_algo == 'bestcoverage':
    # word_ranks = rank_nodes_by_bestcoverage(
        # graph, k=n_keyterms, c=kwargs.get('c', 1), alpha=kwargs.get('alpha', 1.0))

# bail out here if all we wanted was key *words* and not *terms*
top_n = int(n_keyterms * len(word_ranks))

if join_key_words is False:
    keyphrases = [(word, score) for word, score in
            sorted(word_ranks.items(), key=itemgetter(1), reverse=True)[:top_n]]

top_word_ranks = {word: rank for word, rank in
                  sorted(word_ranks.items(), key=itemgetter(1), reverse=True)[:top_n]}

# join consecutive key words into key terms
seen_joined_key_terms = set()
joined_key_terms = []

for key, group in itertools.groupby(wordTokens, lambda word: word in top_word_ranks):
    if key is True:
        words = list(group)
        term = ' '.join(words)
        if term in seen_joined_key_terms:
            continue
        seen_joined_key_terms.add(term)
        joined_key_terms.append((term, sum(word_ranks[word] for word in words)))

keyphrases = sorted(joined_key_terms, key=itemgetter(1), reverse=True)[:top_n]
keyphrases.append([(word, score) for word, score in
            sorted(word_ranks.items(), key=itemgetter(1), reverse=True)[:top_n]])

for keyphrase in keyphrases:
    str = [x for x in keyphrase]
    if(len([x for x in key][0].split())>5):
        keyphrases.remove(key)

