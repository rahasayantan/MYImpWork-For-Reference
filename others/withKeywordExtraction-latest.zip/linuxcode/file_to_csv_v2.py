# -*- coding: utf-8 -*-
"""
Created on Sat May 14 16:20:05 2016

@author: Raha
"""

from nltk.corpus import PlaintextCorpusReader
import numpy as np
import pandas as pd
from paramConfig  import config
import sys
import  re
sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
r = re.compile(r"\s")

corpusRoot = config.outfilePath
inputPath = config.inputPath
fileList = PlaintextCorpusReader(corpusRoot, '.*.txt')
fileList.fileids()


data =  pd.DataFrame()
data['fileId'] = fileList.fileids()
data['score'] = np.arange(0,len(data['fileId']))

########Should be commented later on

# data.loc[0:55,'score']=1
# data.loc[56:80,'score']=2
# data.loc[81:85,'score']=3
# data.loc[86:95,'score']=4
# data.loc[96:,'score']=2
# ############################
# data['content'] = str('Empty')


for fileid in fileList.fileids():
    with open(corpusRoot+fileid, 'r') as myfile:
        txt=unicode(myfile.read().replace('\n', ' ').replace(',',' ').replace('\t',' ').strip(),errors="replace")
        txt = r.sub(' ',txt)
        data.loc[data['fileId']==fileid,'content']=txt
        
data
data.to_csv(inputPath+"file_corpora.csv",sep=',',index =False)
