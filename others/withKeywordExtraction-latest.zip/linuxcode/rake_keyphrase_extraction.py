##Document Dump
from nltk.corpus import PlaintextCorpusReader
import numpy as np
import pandas as pd
from paramConfig_lin  import config
import sys
import  re
import nltk


sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
r = re.compile(r"\s")
stopwords = config.stopwords
corpusRoot = config.outfilePath
inputPath = config.inputPath
inputPath = config.inputPath
data = pd.read_csv(inputPath+"file_corpora.csv",sep=',')
data = data.fillna('')
text=''
for i in np.arange(len(data)):
    text='.'.join([text,data.loc[i,'content']])
text = re.sub(r'[^a-zA-Z- ]',r' ',text)
sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
wordTokens = nltk.word_tokenize(' '.join(sent_detector.tokenize(text.strip())))
wordTokens = [x for x in wordTokens if x not in '']
wordTokens = [x.lower() for x in wordTokens]
wordTokens = [x for x in wordTokens if x not in stopwords]
text = ' '.join(wordTokens)


## key word extraction  using Rake -- best so far
import rake
import operator
rake_object = rake.Rake("SmartStoplist.txt", 4, 3, 2)#Each word has at least 4 characters, Each phrase has at most 5 words, Each keyword appears in the text at least 20 times
#sample_file = open("data/docs/fao_test/w2167e.txt", 'r')
#text = sample_file.read()
#text = data['content'][0]
keywords = rake_object.run(text)
print "Keywords:", keywords

for keyword in keywords[0:(len(keywords)//3)]:
    print "Keyword: ", keyword[0].encode('utf-8'), ", score: ", keyword[1]       

stoppath = "SmartStoplist.txt"

rake_object = rake.Rake(stoppath)

sentenceList = rake.split_sentences(text)
stopwordpattern = rake.build_stop_word_regex(stoppath)
phraseList = rake.generate_candidate_keywords(sentenceList, stopwordpattern)
wordscores = rake.calculate_word_scores(phraseList)
keywordcandidates = rake.generate_candidate_keyword_scores(phraseList, wordscores)
sortedKeywords = sorted(keywordcandidates.iteritems(), key=operator.itemgetter(1), reverse=True)
totalKeywords = len(sortedKeywords)

#for keyword in sortedKeywords[0:(totalKeywords / 3)]:
#    print "Keyword: ", keyword[0], ", score: ", keyword[1]       

#remove non ascii
#import unicodedata
#unicodedata.normalize('NFKD', title).encode('ascii','ignore')

import pandas as pd
keyfile=pd.DataFrame(keywords)
keyfile.to_csv("keyphrases_rake.csv")
  
    
#do keyword extraction via graph db semantic and paradigmic

#do keyword extraction via tfidf
