import pandas as pd
import os
from paramConfig  import config
import sys
import conv_file_to_txt as cv

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')

filePath = config.filePath
rfpinputPath = config.rfpinPath
inputPath = config.inputPath
outputPath = config.outfilePath

alldirs = []

for root, dirs, files in os.walk(rfpinputPath):
    for dir in dirs:
        alldirs.append(os.path.join(root, dir))
if (len(alldirs) ==0):
    alldirs.append(root)
for inputPath in alldirs:
    print inputPath
    for file_nm in os.listdir(inputPath):
        if file_nm.startswith('~$'):
            continue
        elif file_nm.lower().endswith('.ppt.pdf'):
            continue
        elif file_nm.lower().endswith(".pdf") or file_nm.lower().endswith(".docx"):
            txt = cv.document_to_text(file_nm,os.path.join(inputPath,file_nm)).replace('\n', ' ').strip()
            f = open(os.path.join(inputPath,file_nm)+'.txt','w')
            f.write(txt)    
            f.close()
        elif file_nm.lower().endswith(".doc"):
            #print(os.path.join(inputPath,file_nm))
            cv.doc_to_text(os.path.join(inputPath,file_nm))
        elif file_nm.lower().endswith(".ppt"):
            txt = cv.ppt_to_text(os.path.join(inputPath,file_nm)).replace('\n', ' ').strip()
            f = open(os.path.join(inputPath,file_nm)+'.txt','w')
            f.write(txt)    
            f.close()
        elif file_nm.lower().lower().endswith(".xlsx") or file_nm.lower().endswith(".xls"):
            txt = cv.xl_to_text(os.path.join(inputPath,file_nm)).replace('\n', ' ').strip()
            f = open(os.path.join(inputPath,file_nm)+'.txt','w')
            f.write(txt)    
            f.close()
        elif file_nm.lower().endswith(".pptx"):
            txt = cv.pptx_to_text(os.path.join(inputPath,file_nm)).replace('\n', ' ').strip()
            f = open(os.path.join(inputPath,file_nm)+'.txt','w')
            f.write(txt)    
            f.close()

# Create and move the files to rfp output path

if not os.path.isdir(os.path.join('', outputPath)):
    os.mkdir(os.path.join('', outputPath))

alldir = []
allfiles = []
for root,dir,files in os.walk(rfpinputPath):
    for file in files:
        if file.endswith(".txt"):
            alldir.append(root)
            allfiles.append(file)
            
data =  pd.DataFrame()
data['filename'] = allfiles
data['filepath'] = alldir
i = x = 0

while i < (len(data)-2):
    myfile = open(os.path.join(data.loc[i,'filepath'],data.loc[i,'filename']),"r")
    txt = myfile.read()
    print len(txt)
    for j in range(i+1,len(data)-1):
        txt1 = txt
        if data.loc[i,'filepath'] == data.loc[j,'filepath'] and data.loc[i,'filename'] == data.loc[j,'filename']:#ideally should not have filename
            myfile2 = open(os.path.join(data.loc[j,'filepath'],data.loc[j,'filename']),"r")
            txt1  =  myfile2.read()
            txt = txt + txt1
            myfile2.close()
            i = j
        else:
            writefile = open(os.path.join(outputPath,data.loc[i,'filepath'].replace("\\","_").replace(" ","_")+"_"+data.loc[i,'filename']).replace(" ","_"),"wb")
            writefile.write(txt)
            writefile.close()
            i = j
            break
    myfile.close()
