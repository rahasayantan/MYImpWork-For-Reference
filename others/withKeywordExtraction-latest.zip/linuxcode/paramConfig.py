import os
import numpy as np
import nltk


############
## Config ##
############
class ParamConfig:
    def __init__(self):
        self.rfpinPath  = 'D:\\AIM-RFP-Repository-Clean\\'
        self.filePath = 'D:\\data-kaggle\\textClassTemplate\\'
        self.outfilePath = 'D:\\AIM-RFP-Repository-txt\\'
        self.inputPath = self.filePath+'data\\'
        self.english_stemmer = nltk.stem.SnowballStemmer('english')
        self.stopwords = nltk.corpus.stopwords.words("english")
        self.stopwords = set(self.stopwords)
        self.token_pattern = r"(?u)\b\w\w+\b"
        self.drop_html_flag=True
        self.exclude_stopword = True
        self.join_str = "_"
        self.tfidf__norm = "l2"
        self.tfidf__max_df = 0.75
        self.tfidf__min_df = 5
        self.bow__max_df = 0.75
        self.bow__min_df = 5
        self.ngram_range = (1,1)
        self.svd_n_components = 300


## initialize a param config                    
config = ParamConfig()
# filePath = config.filePath
# filePath
