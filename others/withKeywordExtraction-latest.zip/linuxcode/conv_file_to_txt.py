# -*- coding: utf-8 -*-
"""
Created on Thu May 19 01:01:52 2016

@author: oracle
"""

from subprocess import Popen, PIPE
from docx import opendocx, getdocumenttext
import textract
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from cStringIO import StringIO
import win32com.client
import os

def convert_pdf_to_txt(path):
    rsrcmgr = PDFResourceManager()
    retstr = StringIO()
    codec = 'utf-8'
    laparams = LAParams()
    device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    fp = file(os.path.join('',path), 'rb')
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    password = ""
    maxpages = 0
    caching = True
    pagenos=set()
    for page in PDFPage.get_pages(fp, pagenos, maxpages=maxpages, password=password,caching=caching, check_extractable=True):
        interpreter.process_page(page)
    fp.close()
    device.close()
    str = retstr.getvalue()
    retstr.close()
    return str

def doc_to_text(file_path):
    if file_path.replace('"','').lower().endswith(".doc"):
        # cmd = ['antiword', file_path]
        # p = Popen(cmd, stdout=PIPE)
        # stdout, stderr = p.communicate()
        # return stdout.decode('ascii', 'ignore')
        wordapp = win32com.client.Dispatch('Word.Application')
        doc = wordapp.Documents.Open(os.path.join('',file_path))
        #wordapp.ActiveDocument.SaveAs(file_path+".txt",FileFormat=win32com.client.constants.wdFormatTextLineBreaks)
        wordapp.ActiveDocument.SaveAs(file_path+".txt",FileFormat=3)
        wordapp.Quit()

def xl_to_text(file_path):
    if file_path.lower().replace('"','').endswith(".xls") or file_path.lower().replace('"','').endswith(".xlsx") :
        text = textract.process(os.path.join('',file_path))
        return text        

def pptx_to_text(file_path):
    if file_path.replace('"','').lower().endswith(".pptx"):
        text = textract.process(os.path.join('',file_path))
        return text          

def ppt_to_text(file_path):
    if file_path.replace('"','').lower().endswith(".ppt"):
        # cmd = ['antiword', file_path]
        # p = Popen(cmd, stdout=PIPE)
        # stdout, stderr = p.communicate()
        # return stdout.decode('ascii', 'ignore')
        wordapp = win32com.client.Dispatch('Powerpoint.Application')#PowerPoint.Application
        doc = wordapp.Presentations.Open(os.path.join('',file_path))
        doc.SaveAs(file_path+".pdf",32)
        wordapp.Quit()
        return convert_pdf_to_txt(file_path+".pdf")
    
def document_to_text(filename, file_path):
    if filename.lower().endswith(".docx"):
        document = opendocx(os.path.join('',file_path))
        paratextlist = getdocumenttext(document)
        newparatextlist = []
        for paratext in paratextlist:
            newparatextlist.append(paratext.encode("utf-8"))
        return '\n\n'.join(newparatextlist)
    elif filename.lower().endswith(".pdf"):
        return convert_pdf_to_txt(file_path)

#document_to_text('OBIEEValueWagon - Copy.pdf','/media/sf_documentClassification/textClassTemplate/data/OBIEEValueWagon - Copy.pdf')

#import PyPDF2
#
#pdfFileObj = open('/media/sf_documentClassification/textClassTemplate/data/OBIEEValueWagon.pdf', 'rb')
#pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
#text = str()
#for pg in range(pdfReader.numPages):
#    text = text + pdfReader.getPage(pg).extractText().strip('\n')
#print(text)