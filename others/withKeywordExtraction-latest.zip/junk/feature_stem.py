# -*- coding: utf-8 -*-
"""
Created on Sun May 15 14:14:18 2016

@author: Raha
"""

import pandas as pd
import re
import nltk
import custNgram
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer

from sklearn.decomposition import TruncatedSVD
from paramConfig import config
ngram_range = (1,2)
filePath = config.filePath
inputPath =  config.inputPath
english_stemmer = config.english_stemmer
stopwords = config.stopwords
token_pattern = config.token_pattern
drop_html_flag=config.drop_html_flag
exclude_stopword = config.exclude_stopword
join_str = config.join_str
tfidf__norm = config.tfidf__norm
tfidf__max_df = config.tfidf__max_df
tfidf__min_df = config.tfidf__min_df
bow__max_df = config.bow__max_df
bow__min_df = config.bow__min_df
ngram_range = config.ngram_range
svd_n_components = config.svd_n_components

def try_divide(x, y, val=0.0):
    """ 
    	Try to divide two numbers
    """
    if y != 0.0:
    	val = float(x) / y
    return val
    
def stem_tokens(tokens, stemmer):
    stemmed = []
    for token in tokens:
        stemmed.append(stemmer.stem(token))
    return stemmed

def preProcess_data(line,token_pattern=token_pattern,exclude_stopword=exclude_stopword):
    token_pattern = re.compile(token_pattern, flags = re.UNICODE | re.LOCALE)
    ##tokenize
    tokens = [x.lower() for x in token_pattern.findall(line)]
    tokens_stemmed = stem_tokens(tokens,english_stemmer)
    if exclude_stopword:
        tokens_stemmed = [x for x in tokens_stemmed if x not in stopwords]
    return tokens_stemmed

def generate_count_features(train):
    train['unigram'] = list(train.apply(lambda x: preProcess_data(x['content']),axis=1))
    train['bigram'] = list(train.apply(lambda x: custNgram.getBigram(x['unigram'],join_str),axis=1))
    train['trigram'] = list(train.apply(lambda x: custNgram.getTrigram(x['unigram'],join_str),axis=1))
    train['fourgram'] = list(train.apply(lambda x: custNgram.getFourgram(x['unigram'],join_str),axis=1))
    ################################
    ## word count and digit count ##
    ################################
    feat_names = "content"
    grams = ["unigram", "bigram", "trigram","fourgram"]
    count_digit = lambda x: sum(1. for w in x if w.isdigit())
#    for feat in feat_names: only required for multiple features
    for gram in grams:
        train["count_of_%s"%(gram)] = list(train.apply(lambda x: len(x[gram]),axis=1))
        train["count_of_unique_%s"%(gram)] = list(train.apply(lambda x: len(set(x[gram])),axis=1))
        train["ratio_of_unique_%s"%(gram)] = map(try_divide,train["count_of_unique_%s"%(gram)],train["count_of_%s"%(gram)])
    ## digit count
    train["count_of_digits_%s"%(feat_names)] = list(train.apply(lambda x: count_digit(x["unigram"]),axis=1))
    train["ratio_of_digits_%s"%(feat_names)] = map(try_divide,train["count_of_digits_%s"%(feat_names)],train["count_of_unigram"])
    return train    

############
## TF-IDF ##
############
class StemmedTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(TfidfVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))
   
def getTFV(token_pattern = token_pattern,
           norm = tfidf__norm,
           max_df = tfidf__max_df,
           min_df = tfidf__min_df,
           ngram_range = (1, 1),
           vocabulary = None,
           stop_words = 'english'):
    tfv = StemmedTfidfVectorizer(min_df=min_df, max_df=max_df, max_features=None, 
                                 strip_accents='unicode', analyzer='word', token_pattern=token_pattern,
                                 ngram_range=ngram_range, use_idf=1, smooth_idf=1, sublinear_tf=1,
                                 stop_words = stop_words, norm=norm, vocabulary=vocabulary)
    return tfv
   

#########
## Bag Of Words (BOW)  ##
#########
class StemmedCountVectorizer(CountVectorizer):
    def build_analyzer(self):
        analyzer = super(CountVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))
   
def getBOW(token_pattern = token_pattern,
           max_df = bow__max_df,
           min_df = bow__min_df,
           ngram_range = (1, 1),
           vocabulary = None,
           stop_words = 'english'):
    bow = StemmedCountVectorizer(min_df=min_df, max_df=max_df, max_features=None, 
                                 strip_accents='unicode', analyzer='word', token_pattern=token_pattern,
                                 ngram_range=ngram_range,
                                 stop_words = stop_words, vocabulary=vocabulary)
    return bow

   


if __name__ == "__main__":
    train = pd.read_csv(inputPath+"file_corpora.tsv" ,sep="\t")
    train  =  generate_count_features(train)
    train.to_csv(inputPath+"xtrain_count_ftr.tsv",sep='\t')
    train_fold = pd.read_csv(inputPath+"fold.tsv" ,sep="\t")
    trainId = train_fold[train_fold['train_fold0'] ==1.0].index.tolist()
    valId = train_fold[train_fold['train_fold0'] ==0.0].index.tolist()
    X_train = train.loc[trainId,].reset_index(drop=True)
    X_valid = train.loc[valId,].reset_index(drop=True)
    vec = getTFV(ngram_range=ngram_range)
    dfTrain_tf = vec.fit_transform(train['content'])
    vocabulary  = vec.vocabulary_
           
    dfTrain = X_train.copy()
    dfTest = X_valid.copy()
    vec_types = [ "tfidf", "bow" ]
    for vec_type in vec_types:
        df = pd.DataFrame()
        if vec_type == "tfidf":
            vec = getTFV(ngram_range=ngram_range,vocabulary=vocabulary)
            dfTrain_tf = vec.fit_transform(X_train['content'])
            df = pd.DataFrame(dfTrain_tf.todense())
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTrain,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            #df_tfid.to_csv(inputPath+"xtrain_tfidf_stem.tsv",sep='\t')
            svd = TruncatedSVD(n_components=svd_n_components, n_iter=15)
            X_svd_train = svd.fit_transform(dfTrain_tf)
            df = pd.DataFrame(X_svd_train)
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTrain,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            df_tfid.to_csv(inputPath+"xtrain_tfidf_stem_svd100.tsv",sep='\t')
 
            dfTrain_tf = vec.fit_transform(X_valid['content'])
            df = pd.DataFrame(dfTrain_tf.todense())
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTest,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            #df_tfid.to_csv(inputPath+"xtest_tfidf_stem.tsv",sep='\t')
            X_svd_train = svd.fit_transform(dfTrain_tf)
            df = pd.DataFrame(X_svd_train)
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTest,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            df_tfid.to_csv(inputPath+"xtest_tfidf_stem_svd100.tsv",sep='\t')
            
        elif vec_type == "bow":
            vec = getTFV(ngram_range=ngram_range,vocabulary=vocabulary)
            dfTrain_tf = vec.fit_transform(X_train['content'])
            df = pd.DataFrame(dfTrain_tf.todense())
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTrain,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            #df_tfid.to_csv(inputPath+"xtrain_bow_stem.tsv",sep='\t')
            svd = TruncatedSVD(n_components=svd_n_components, n_iter=15)
            X_svd_train = svd.fit_transform(dfTrain_tf)
            df = pd.DataFrame(X_svd_train)
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTrain,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            df_tfid.to_csv(inputPath+"xtrain_bow_stem_svd100.tsv",sep='\t')
 
            dfTrain_tf = vec.fit_transform(X_valid['content'])
            df = pd.DataFrame(dfTrain_tf.todense())
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)

            df.columns = col_nm
            frames =  [dfTest,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            #df_tfid.to_csv(inputPath+"xtest_bow_stem.tsv",sep='\t')
            X_svd_train = svd.fit_transform(dfTrain_tf)
            df = pd.DataFrame(X_svd_train)
            col_nm = []
            for col in df.columns:
                col = 'w'+str(col)
                col_nm.append(col)
            df.columns = col_nm
            frames =  [dfTest,df]
            df_tfid = pd.concat(frames,axis=1)
            df_tfid.drop('content', axis=1, inplace=True)
            df_tfid.drop('unigram', axis=1, inplace=True)
            df_tfid.drop('bigram', axis=1, inplace=True)
            df_tfid.drop('trigram', axis=1, inplace=True)
            df_tfid.drop('fourgram', axis=1, inplace=True)
            df_tfid.to_csv(inputPath+"xtest_bow_stem_svd100.tsv",sep='\t')

