# -*- coding: utf-8 -*-
"""
Created on Sun May 15 14:14:18 2016

@author: Raha
"""

import pandas as pd
import re
import nltk
import custNgram

english_stemmer = nltk.stem.SnowballStemmer('english')
stopwords = nltk.corpus.stopwords.words("english")
stopwords = set(stopwords)
token_pattern = r"(?u)\b\w\w+\b"
drop_html_flag=True
exclude_stopword = True
join_str = "_"

def try_divide(x, y, val=0.0):
    """ 
    	Try to divide two numbers
    """
    if y != 0.0:
    	val = float(x) / y
    return val
    
def stem_tokens(tokens, stemmer):
    stemmed = []
    for token in tokens:
        stemmed.append(stemmer.stem(token))
    return stemmed

def preProcess_data(line,token_pattern=token_pattern,exclude_stopword=exclude_stopword):
    token_pattern = re.compile(token_pattern, flags = re.UNICODE | re.LOCALE)
    ##tokenize
    tokens = [x.lower() for x in token_pattern.findall(line)]
    tokens_stemmed = stem_tokens(tokens,english_stemmer)
    if exclude_stopword:
        tokens_stemmed = [x for x in tokens_stemmed if x not in stopwords]
    return tokens_stemmed

if __name__ == "__main__":
    train = pd.read_csv("D:\\data-kaggle\\textClassTemplate\\data\\file_corpora.txt" ,sep="\t")
    #unigram
    train['unigram'] = list(train.apply(lambda x: preProcess_data(x['content']),axis=1))
    train['bigram'] = list(train.apply(lambda x: custNgram.getBigram(x['unigram'],join_str),axis=1))
    train['trigram'] = list(train.apply(lambda x: custNgram.getTrigram(x['unigram'],join_str),axis=1))
    train['fourgram'] = list(train.apply(lambda x: custNgram.getFourgram(x['unigram'],join_str),axis=1))
    ################################
    ## word count and digit count ##
    ################################

    feat_names = ["content"]
    grams = ["unigram", "bigram", "trigram","fourgram"]
    count_digit = lambda x: sum(1. for w in x if w.isdigit())
#    for feat in feat_names: only required for multiple features
    for gram in grams:
        train["count_of_%s"%(gram)] = list(train.apply(lambda x: len(x[gram]),axis=1))
        train["count_of_unique_%s"%(gram)] = list(train.apply(lambda x: len(set(x[gram])),axis=1))
        train["ratio_of_unique_%s"%(gram)] = map(try_divide,train["count_of_unique_%s"%(gram)],train["count_of_%s"%(gram)])
    ## digit count
    train["count_of_digits_%s"%(feat_names)] = list(train.apply(lambda x: count_digit(x["unigram"]),axis=1))
    train["ratio_of_digits_%s"%(feat_names)] = map(try_divide,train["count_of_digits_%s"%(feat_names)],train["count_of_unigram"])

train.to_csv("D:\\data-kaggle\\textClassTemplate\\data\\xtrain_count_ftr.csv",sep='\t')

train    
