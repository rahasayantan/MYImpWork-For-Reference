# -*- coding: utf-8 -*-
"""
Created on Sat May 14 16:20:05 2016

@author: Raha
"""

import conv_file_to_txt as cv

from nltk.corpus import PlaintextCorpusReader
import sys
import numpy as np
import pandas as pd
import os
from paramConfig  import config

filePath = config.filePath
inputPath = config.inputPath
#fileLst =[]
# convert PDF, DOCX

for file_nm in os.listdir(inputPath):
    if file_nm.endswith(".pdf") or file_nm.endswith(".docx"):
        txt = cv.document_to_text(file_nm,inputPath+file_nm).replace('\n', '').strip()
        f = open(inputPath+file_nm+'.txt','w')
        f.write(txt)    
        f.close()
    elif file_nm.endswith(".doc"):
        cv.doc_to_text(inputPath+file_nm)

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')


corpusRoot = filePath+'/data'
fileList = PlaintextCorpusReader(corpusRoot, '.*.txt')
fileList.fileids()


data =  pd.DataFrame()
data['fileId'] = fileList.fileids()
data['score'] = np.arange(0,len(data['fileId']))

########Should be commented later on

data.loc[0:55,'score']=1
data.loc[56:80,'score']=2
data.loc[81:85,'score']=3
data.loc[86:95,'score']=4
data.loc[96:,'score']=2
############################
data['content'] = str('Empty')


for fileid in fileList.fileids():
    with open(filePath+'data/'+fileid, 'r') as myfile:
        txt=unicode(myfile.read().replace('\n', '').replace('\t','').strip(),errors="replace")
        data.loc[data['fileId']==fileid,'content']=txt
        
data
data.to_csv(filePath+"/data/file_corpora.tsv",sep='\t',index =False)
