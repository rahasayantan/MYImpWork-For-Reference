"""
From this paper: https://web.eecs.umich.edu/~mihalcea/papers/mihalcea.emnlp04.pdf

External dependencies: nltk, numpy, networkx

Based on github text rank implementation from  david adamojr
"""
import networkx as nx
from nltk.corpus import PlaintextCorpusReader
import numpy as np
import pandas as pd
from paramConfig  import config
import sys
import io
import nltk
import itertools
from operator import itemgetter
import networkx as nx
import os
from nltk.tokenize.punkt import PunktSentenceTokenizer
import pandas as pd
import re
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from copy import copy
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from sklearn.decomposition import TruncatedSVD
from paramConfig import config
import imputilities
import ngram

ngram_range = config.ngram_range
filePath = config.filePath
inputPath =  config.inputPath
english_stemmer = config.english_stemmer
stopwords = config.stopwords
token_pattern = config.token_pattern
drop_html_flag=config.drop_html_flag
exclude_stopword = config.exclude_stopword
join_str = config.join_str
tfidf__norm = config.tfidf__norm
tfidf__max_df = config.tfidf__max_df
tfidf__min_df = config.tfidf__min_df
bow__max_df = config.bow__max_df
bow__min_df = config.bow__min_df
svd_n_components = config.svd_n_components

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
inputPath = config.inputPath
data = pd.read_csv(inputPath+"file_corpora.csv",sep=',')
data = data.fillna('')

cust_stopword = imputilities.load_cust_stop_words("SmartStoplist.txt")
cust_stopword = set(cust_stopword)

#retrieve each of the articles
#text = data['content'][0]
text=''
for i in np.arange(len(data)):
    text='.'.join([text,data.loc[i,'content']])
text = re.sub(r'[^a-zA-Z- ]',r' ',text)
sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
wordTokens = nltk.word_tokenize(' '.join(sent_detector.tokenize(text.strip())))
wordTokens = [x for x in wordTokens if x not in '']
wordTokens = [x.lower() for x in wordTokens]
#wordTokens = imputilities.stem_tokens(wordTokens,english_stemmer)
wordTokens = [x for x in wordTokens if x not in stopwords]
wordTokens = [x for x in wordTokens if x not in cust_stopword]

wordTokens = wordTokens+(ngram.getBigram(wordTokens,' '))

#sentences = sent_detector.tokenize(document.strip())#text
sentences= wordTokens

## convert to tfidf for bag of words

vec = imputilities.getTFV(ngram_range=ngram_range)
normalized_matrix = vec.fit_transform(sentences)#text

## Convert to Graph
similarity_graph = normalized_matrix * normalized_matrix.T
similarity_graph.toarray()
graph = nx.from_scipy_sparse_matrix(similarity_graph)
calculated_page_rank = nx.pagerank(graph, weight='weight')

#most important words in ascending order of importance
textlist =  list(imputilities.unique_everseen([x for x in wordTokens]))
#for key, value in vec.vocabulary_.iteritems():
#    textlist.append(key)

keyphrases = sorted(((calculated_page_rank[i],s) for i,s in enumerate(textlist)),reverse=True)

#the number of keyphrases returned will be relative to the size of the text (a third of the number of vertices)
aThird = len(textlist) / 3
keyphrases = keyphrases[0:aThird+1]

#this will be used to determine adjacent words in order to construct keyphrases with two words
#take keyphrases with multiple words into consideration as done in the paper - if two words are adjacent in the text and are selected as keywords, join them
#together
# modifiedKeyphrases = set([])
# dealtWith = set([]) #keeps track of individual keywords that have been joined to form a keyphrase
# i = 0
# j = 1


# while j < len(textlist):
    # firstWord = textlist[i]
    # secondWord = textlist[j]
# #    print(firstWord);print(secondWord)
    # if firstWord in [x[1] for x in keyphrases] and secondWord in [x[1] for x in keyphrases]:
        # print("in if")
        # keyphrase = firstWord + ' ' + secondWord
        # modifiedKeyphrases.add(keyphrase)
        # dealtWith.add(firstWord)
        # dealtWith.add(secondWord)
    # else:
        # print("in else")
        # if firstWord in keyphrases and firstWord not in dealtWith: 
            # modifiedKeyphrases.add(firstWord)

        # #if this is the last word in the text, and it is a keyword,
        # #it definitely has no chance of being a keyphrase at this point    
        # if j == len(textlist)-1 and secondWord in keyphrases and secondWord not in dealtWith:
            # modifiedKeyphrases.add(secondWord)
    
    # i = i + 1
    # j = j + 1
    # print(j)
    # print(len(textlist))

    
import pandas as pd

keyphrases = [x[1].encode('ascii','ignore') for x in keyphrases]    
keyphrases = pd.DataFrame(list(keyphrases))
keyphrases.to_csv('keyphrases_graph_tfidf.csv',index=False)