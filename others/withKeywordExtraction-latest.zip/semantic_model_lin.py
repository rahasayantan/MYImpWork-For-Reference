import collections
import itertools
import networkx as nx
from cytoolz import itertoolz
from nltk.corpus import PlaintextCorpusReader
import numpy as np
import pandas as pd
from paramConfig_lin  import config
import sys
import  re
import imputilities
import nltk
import ngram
import operator

sys.path.append("../")
reload(sys)
sys.setdefaultencoding('utf8')
r = re.compile(r"\s")
stopwords = config.stopwords

inputPath = config.inputPath
data = pd.read_csv(inputPath+"file_corpora.csv",sep=',')
data = data.fillna('')
text=''
for i in np.arange(len(data)):
    text='.'.join([text,data.loc[i,'content']])
text = re.sub(r'[^a-zA-Z- ]',r' ',text)


cust_stopword = imputilities.load_cust_stop_words("SmartStoplist.txt")
cust_stopword = set(cust_stopword)

def terms_to_semantic_network(terms,
                              window_width=10,
                              edge_weighting='cooc_freq'):

    windows = itertoolz.sliding_window(window_width, terms)
    graph = nx.Graph()

    if edge_weighting == 'cooc_freq':
        cooc_mat = collections.defaultdict(lambda: collections.defaultdict(int))
        for window in windows:
            for w1, w2 in itertools.combinations(sorted(window), 2):
                cooc_mat[w1][w2] += 1
        graph.add_edges_from(
            (w1, w2, {'weight': cooc_mat[w1][w2]})
            for w1, w2s in cooc_mat.items() for w2 in w2s)

    elif edge_weighting == 'binary':
        graph.add_edges_from(
            w1_w2 for window in windows
            for w1_w2 in itertools.combinations(window, 2))

    return graph

  
window_width=3
edge_weighting='cooc_freq'
join_key_words=True
n_keyterms=.01


sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
wordTokens = nltk.word_tokenize(' '.join(sent_detector.tokenize(text.strip())))
wordTokens = [x.lower().strip() for x in wordTokens]
from nltk.stem import WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()
wordTokens = [wordnet_lemmatizer.lemmatize(x) for x in wordTokens]
tagged = nltk.pos_tag(wordTokens)
tagged = imputilities.filter_for_tags(tagged)
tagged = [x[0] for x in imputilities.normalize(tagged)]
wordTokens = [x for x in wordTokens if x not in stopwords]
textlist =  wordTokens#list(imputilities.unique_everseen([x for x in wordTokens]))
#wordTokens = imputilities.stem_tokens(wordTokens,english_stemmer)
wordTokens = [x for x in tagged if x not in cust_stopword]
#wordTokens = wordTokens+(ngram.getBigram(wordTokens,' '))


if isinstance(n_keyterms, float):
    if not 0.0 < n_keyterms <= 1.0:
        raise ValueError('`n_keyterms` must be an int, or a float between 0.0 and 1.0')
    n_keyterms = int(n_keyterms * len(set(wordTokens)))

graph = terms_to_semantic_network(
    wordTokens, window_width=window_width, edge_weighting=edge_weighting)

word_ranks = nx.pagerank_scipy(graph, weight='weight')
# elif ranking_algo == 'divrank':
    # word_ranks = rank_nodes_by_divrank(
        # graph, r=None, lambda_=kwargs.get('lambda_', 0.5), alpha=kwargs.get('alpha', 0.5))
# elif ranking_algo == 'bestcoverage':
    # word_ranks = rank_nodes_by_bestcoverage(
        # graph, k=n_keyterms, c=kwargs.get('c', 1), alpha=kwargs.get('alpha', 1.0))

# bail out here if all we wanted was key *words* and not *terms*
top_n = int(n_keyterms * len(word_ranks))

#if join_key_words is False:
keyphrases = [(word, score) for word, score in
        sorted(word_ranks.items(), key=operator.itemgetter(1), reverse=True)]

top_word_ranks = {word: rank for word, rank in
                  sorted(word_ranks.items(), key=operator.itemgetter(1), reverse=True)[:10000]}

# join consecutive key words into key terms
seen_joined_key_terms = set()
joined_key_terms = []

keyphrases = [x[0].encode('ascii','ignore') for x in keyphrases]    
keyphrases = pd.DataFrame(list(keyphrases))
keyphrases.to_csv('keyphrases_graph_semantic_pos.csv',index=False)
topkeyphrases = [x[0].encode('ascii','ignore') for x in top_word_ranks]    
topkeyphrases = pd.DataFrame(list(top_word_ranks))
topkeyphrases.to_csv('keyphrases_graph_semantic_pos_500.csv',index=False)
keyphrases.columns=['txt']
topkeyphrases.columns=['txt']

modifiedKeyphrases = []
modifiedKeyweights = []
dealtWith = set([]) #keeps track of individual keywords that have been joined to form a keyphrase
h = 0
i = 1
j = 2

while j < len(textlist):
    firstWord = textlist[h]
    secondWord = textlist[i]
    thirdWord = textlist[j]

    if firstWord in [x for x in topkeyphrases['txt']] and secondWord in [x for x in topkeyphrases['txt']] and thirdWord in [x for x in topkeyphrases['txt']] and (firstWord!=secondWord and firstWord!=thirdWord and thirdWord!=secondWord):
        keyphrase = firstWord + ' ' + secondWord +  ' ' + thirdWord
        keyweights = top_word_ranks.get(firstWord) + top_word_ranks.get(secondWord) + top_word_ranks.get(thirdWord)
        modifiedKeyphrases.append(keyphrase)
        modifiedKeyweights.append(keyweights)
        dealtWith.add(firstWord)
        dealtWith.add(secondWord)
        dealtWith.add(thirdWord)
    elif firstWord in [x for x in topkeyphrases['txt']] and secondWord in [x for x in topkeyphrases['txt']] and firstWord!=secondWord:
        keyphrase = firstWord + ' ' + secondWord 
        keyweights = top_word_ranks.get(firstWord) + top_word_ranks.get(secondWord)
        modifiedKeyphrases.append(keyphrase)
        modifiedKeyweights.append(keyweights)
        dealtWith.add(firstWord)
        dealtWith.add(secondWord)
    else:
        if firstWord in [x for x in topkeyphrases['txt']] and firstWord not in dealtWith: 
            modifiedKeyphrases.append(firstWord)
            keyweights = top_word_ranks.get(firstWord)
            modifiedKeyweights.append(keyweights)
    #if this is the last word in the text, and it is a keyword,
    #it definitely has no chance of being a keyphrase at this point    
        if j == len(textlist)-1 and thirdWord in [x for x in topkeyphrases['txt']] and thirdWord not in dealtWith:
            modifiedKeyphrases.append(thirdWord)
            keyweights = top_word_ranks.get(thirdWord)
            modifiedKeyweights.append(keyweights)

    h = h + 1
    i = i + 1
    j = j + 1
    print(len(modifiedKeyweights))
  
modifiedKeyphrases = pd.DataFrame(list(modifiedKeyphrases),list(modifiedKeyweights))
modifiedKeyphrases.columns=['txt']
modifiedKeyphrases = modifiedKeyphrases.drop_duplicates()
modifiedKeyphrases = modifiedKeyphrases.reset_index()
modifiedKeyphrases.to_csv('modifiedKeyphrases_graph_semantic_pos_500.csv',index=True)

for i in range(1,modifiedKeyphrases.shape[0]):
    if modifiedKeyphrases.loc[i-1,'txt'] in modifiedKeyphrases.loc[i,'txt'] :
        modifiedKeyphrases.loc[i-1,'txt']=''
    elif modifiedKeyphrases.loc[i,'txt'] in modifiedKeyphrases.loc[i-1,'txt']:
        modifiedKeyphrases.loc[i,'txt']=''
modifiedKeyphrases =  modifiedKeyphrases[modifiedKeyphrases['txt']!='']
modifiedKeyphrases.to_csv('modifiedKeyphrases_graph_semantic_pos_500.csv',index=True)
